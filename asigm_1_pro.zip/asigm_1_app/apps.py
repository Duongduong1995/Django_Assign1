from django.apps import AppConfig


class Asigm1AppConfig(AppConfig):
    name = 'asigm_1_app'
